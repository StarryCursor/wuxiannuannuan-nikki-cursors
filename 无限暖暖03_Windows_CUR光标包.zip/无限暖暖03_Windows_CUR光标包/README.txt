无限暖暖-03 Windows 光标包

本版本根据你的指定，保留并映射为这些 Windows 状态：

1. Arrow（正常选择）        → 01_Normal_Select.cur
2. IBeam（文本选择）        → 02_Text_Select.cur
3. Wait（忙碌）             → 03_Busy.cur
4. Hand（链接选择）         → 04_Link_Select.cur
5. No（不可用）             → 05_Unavailable.cur
6. Help（帮助选择）         → 06_Help_Select.cur
7. SizeAll（移动）          → 07_Move_SizeAll.cur
8. SizeWE（水平调整大小）   → 08_Horizontal_SizeWE.cur
9. SizeNS（垂直调整大小）   → 09_Vertical_SizeNS.cur
10. SizeNESW（对角线调整大小2）→ 10_Diagonal2_SizeNESW.cur
11. SizeNWSE（对角线调整大小1）→ 11_Diagonal1_SizeNWSE.cur
12. AppStarting（后台工作） → 12_Background_Working_AppStarting.cur

每个 .cur 文件内均包含 32、48、64、96、128、256 六档尺寸，并保留原始热点。

快速安装：
1. 下载后打开 Recommended_Windows_Scheme 文件。
2. 右键 Install.inf，选择“安装”。
3. 打开 Windows 设置 → 蓝牙和设备 → 鼠标 → 其他鼠标设置 → 指针。
4. 在“方案”中选择“无限暖暖-03（精简映射+后台工作）”，点击应用。

若无法快速安装：
1. 下载后，打开系统设置-辅助功能-鼠标指针与触控-自定义指针图像/自定义指针样式。
3. 针对每一个状态的光标，点击“浏览”，打开下载的文件夹中 Cursors 文件，选择其对应状态的光标，进行一一替换。

说明：
- 未提供的其他 Windows 状态将保持为空，通常会继续使用系统默认指针。
